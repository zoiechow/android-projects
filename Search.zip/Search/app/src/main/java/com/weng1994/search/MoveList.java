package com.weng1994.search;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.TextView;

public class MoveList extends AppCompatActivity {
    private TextView tv;
    private  ImageView Iv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mode);

        Bundle bundle=getIntent().getExtras();
        int id=bundle.getInt("photo");
        String message=bundle.getString("message");
        Iv=(ImageView) findViewById(R.id.Iv);
        Iv.setImageResource(id);
        tv=(TextView) findViewById(R.id.tv_message);
        tv.setText(message);
    }
}
