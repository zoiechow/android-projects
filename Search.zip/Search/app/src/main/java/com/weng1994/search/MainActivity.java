package com.weng1994.search;


import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private ImageView ivDeleteText;
    private EditText etSearch;
    private ListView Lv;

    private ArrayAdapter<String> listAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Lv=(ListView)findViewById(R.id.listview) ;
        ivDeleteText = (ImageView) findViewById(R.id.ivDeleteText);
        etSearch = (EditText) findViewById(R.id.etSearch);





        ivDeleteText.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                etSearch.setText("");
            }
        });





        final String[] name = new String[]{"张国荣", "张学友", "谭咏麟"};
        final String[] info=new String[]{"张国荣，1956年9月12日生于香港，歌手、演员、音乐人；",
                "张学友，歌手、演员，1961年7月10日出生于香港，",
                "谭咏麟，1950年8月23日出生于香港，中国香港男歌手、音乐人、演员。"};
        final String[] message = new String[]{"张国荣[1]，1956年9月12日生于香港，歌手、演员、音乐人；",
                "张学友，歌手、演员，1961年7月10日出生于香港，",
                "谭咏麟，1950年8月23日出生于香港，中国香港男歌手、音乐人、演员。"};
        final int[] photo = new int[]{R.drawable.p1, R.drawable.p2, R.drawable.p3};
        List<Map<String, Object>> data = new ArrayList();

        Map<String, Object> map1 = new HashMap<>();
        map1.put("photo", R.drawable.p1);
        map1.put("name", name[0]);
        map1.put("info", info[0]);
        data.add(map1);

        Map<String, Object> map2 = new HashMap<>();
        map2.put("photo", R.drawable.p2);
        map2.put("name", name[1]);
        map2.put("info", info[1]);
        data.add(map2);

        Map<String, Object> map3 = new HashMap<>();
        map3.put("photo", R.drawable.p3);
        map3.put("name", name[2]);
        map3.put("info", info[2]);
        data.add(map3);
//
//        Lv.setAdapter(new SimpleAdapter
//                (this, data, R.layout.item, new String[]
//                        {"photo", "name","info"}, new int[]
//                        {R.id.iv, R.id.tv_name,R.id.tv_info}));
//
//        Lv.setAdapter(new SimpleAdapter(this, data, R.layout.item, new String[]{"photo", "name","info"},
//                new int[]{R.id.iv, R.id.tv_name,R.id.tv_info}));



        final SimpleAdapter adapter = new SimpleAdapter(this, data, R.layout.item, new String[]{"photo", "name","info"},
                new int[]{R.id.iv, R.id.tv_name,R.id.tv_info});

        Lv.setAdapter(adapter);

//        listAdapter = new ArrayAdapter<String>(this,
//                android.R.layout.simple_list_item_1,android.R.id.text1,
//                name);
//        Lv.setAdapter(listAdapter);

//        Lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//
//            @Override
//            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//// make Toast when click
//                Toast.makeText(getApplicationContext(), "Position " + position, Toast.LENGTH_LONG).show();
//            }
//        });
        Lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> arg0, View ar1, int arg2, long arg3) {
                Bundle bundle = new Bundle();
                bundle.putInt("photo", photo[arg2]);
                bundle.putString("info",info[arg2]);
                bundle.putString("message", message[arg2]);
                Intent intent = new Intent();
                intent.putExtras(bundle);
                intent.setClass(MainActivity.this, MoveList.class);
                Log.i("message", message[arg2]);
                startActivity(intent);
            }
        });



        //Lv.setTextFilterEnabled(true);

//        etSearch.addTextChangedListener(new TextWatcher() {
//
//            public void onTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {
//                String aa = arg0.toString();
//                Pattern p = Pattern.compile(aa);
//
//                // TODO Auto-generated method stub
//
//            }
//
//            public void beforeTextChanged(CharSequence arg0, int arg1, int arg2,
//                                          int arg3) {
//                // TODO Auto-generated method stub
//
//            }
//
//            public void afterTextChanged(Editable s) {
//                if (s.length() == 0) {
//                    ivDeleteText.setVisibility(View.GONE);
//                } else {
//                    ivDeleteText.setVisibility(View.VISIBLE);
//                    //myhandler.post(eChanged);
//                }
//            }
//        });


    }





}
